#ifndef _PRIMEDECOMPOSE_H_
#define _PRIMEDECOMPOSE_H_
#include <gmp.h>
int decompose(mpz_t n, mpz_t *o);
#endif
